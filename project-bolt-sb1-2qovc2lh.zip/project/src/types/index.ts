export interface User {
  id: string;
  email: string;
  role: 'doctor' | 'patient';
  name: string;
  avatar?: string;
  specialization?: string; // for doctors
  license?: string; // for doctors
  dateOfBirth?: string; // for patients
  phone?: string;
}

export interface Patient {
  id: string;
  name: string;
  email: string;
  phone: string;
  dateOfBirth: string;
  gender: 'male' | 'female' | 'other';
  address: string;
  emergencyContact: string;
  medicalHistory: MedicalRecord[];
  allergies: string[];
  currentMedications: string[];
}

export interface MedicalRecord {
  id: string;
  patientId: string;
  doctorId: string;
  doctorName: string;
  date: string;
  diagnosis: string;
  symptoms: string[];
  prescription: Prescription[];
  notes: string;
  followUpDate?: string;
  documents: Document[];
}

export interface Prescription {
  id: string;
  medication: string;
  dosage: string;
  frequency: string;
  duration: string;
  instructions: string;
}

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  doctorId: string;
  doctorName: string;
  date: string;
  time: string;
  duration: number;
  status: 'scheduled' | 'completed' | 'cancelled';
  reason: string;
  notes?: string;
  type: 'consultation' | 'follow-up' | 'emergency';
}

export interface ChatMessage {
  id: string;
  userId: string;
  message: string;
  timestamp: string;
  isAI: boolean;
  analysis?: HealthAnalysis;
}

export interface HealthAnalysis {
  symptoms: string[];
  possibleConditions: string[];
  recommendations: string[];
  urgency: 'low' | 'medium' | 'high';
  suggestedActions: string[];
}

export interface Document {
  id: string;
  name: string;
  type: string;
  url: string;
  uploadDate: string;
  description?: string;
}

export interface DietPlan {
  id: string;
  patientId: string;
  title: string;
  description: string;
  meals: Meal[];
  duration: string;
  createdBy: string;
  createdDate: string;
}

export interface Meal {
  id: string;
  name: string;
  time: string;
  foods: string[];
  calories: number;
  notes?: string;
}

export interface HomeRemedy {
  id: string;
  condition: string;
  title: string;
  description: string;
  ingredients: string[];
  instructions: string[];
  precautions: string[];
  effectiveness: number;
}