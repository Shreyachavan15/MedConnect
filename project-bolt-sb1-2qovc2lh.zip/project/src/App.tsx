import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import LoginForm from './components/LoginForm';
import Navigation from './components/Navigation';
import Dashboard from './components/Dashboard';
import AIChat from './components/AIChat';
import DocumentScanner from './components/DocumentScanner';
import DietPlans from './components/DietPlans';
import HomeRemedies from './components/HomeRemedies';

// Placeholder components for missing routes
const AppointmentsPage = () => (
  <div className="p-6">
    <div className="bg-white rounded-xl shadow-sm p-8 border border-gray-100">
      <h1 className="text-3xl font-bold text-gray-800 mb-4">Appointments</h1>
      <p className="text-gray-600 mb-6">Manage your appointments and schedule new ones.</p>
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-blue-800">This feature is coming soon! You'll be able to book and manage appointments here.</p>
      </div>
    </div>
  </div>
);

const PatientsPage = () => (
  <div className="p-6">
    <div className="bg-white rounded-xl shadow-sm p-8 border border-gray-100">
      <h1 className="text-3xl font-bold text-gray-800 mb-4">Patients</h1>
      <p className="text-gray-600 mb-6">View and manage your patient records.</p>
      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <p className="text-green-800">Patient management system is under development.</p>
      </div>
    </div>
  </div>
);

const RecordsPage = () => (
  <div className="p-6">
    <div className="bg-white rounded-xl shadow-sm p-8 border border-gray-100">
      <h1 className="text-3xl font-bold text-gray-800 mb-4">Medical Records</h1>
      <p className="text-gray-600 mb-6">Access your complete medical history and records.</p>
      <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
        <p className="text-purple-800">Medical records system will be available soon.</p>
      </div>
    </div>
  </div>
);

const DocumentsPage = () => (
  <div className="p-6">
    <div className="bg-white rounded-xl shadow-sm p-8 border border-gray-100">
      <h1 className="text-3xl font-bold text-gray-800 mb-4">Documents</h1>
      <p className="text-gray-600 mb-6">Manage and organize your medical documents.</p>
      <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
        <p className="text-orange-800">Document management features are being developed.</p>
      </div>
    </div>
  </div>
);

const ProfilePage = () => (
  <div className="p-6">
    <div className="bg-white rounded-xl shadow-sm p-8 border border-gray-100">
      <h1 className="text-3xl font-bold text-gray-800 mb-4">Profile</h1>
      <p className="text-gray-600 mb-6">Manage your profile information and preferences.</p>
      <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-4">
        <p className="text-indigo-800">Profile management features are coming soon.</p>
      </div>
    </div>
  </div>
);

const SettingsPage = () => (
  <div className="p-6">
    <div className="bg-white rounded-xl shadow-sm p-8 border border-gray-100">
      <h1 className="text-3xl font-bold text-gray-800 mb-4">Settings</h1>
      <p className="text-gray-600 mb-6">Configure your application settings and preferences.</p>
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
        <p className="text-gray-800">Settings panel will be available soon.</p>
      </div>
    </div>
  </div>
);

const AppRoutes = () => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!user) {
    return <LoginForm />;
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Navigation />
      <main className="flex-1">
        <Routes>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/chat" element={<AIChat />} />
          <Route path="/scan" element={<DocumentScanner />} />
          <Route path="/diet" element={<DietPlans />} />
          <Route path="/remedies" element={<HomeRemedies />} />
          <Route path="/appointments" element={<AppointmentsPage />} />
          <Route path="/patients" element={<PatientsPage />} />
          <Route path="/records" element={<RecordsPage />} />
          <Route path="/documents" element={<DocumentsPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </main>
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <AppRoutes />
      </Router>
    </AuthProvider>
  );
}

export default App;