import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { 
  Calendar, 
  Users, 
  MessageCircle, 
  FileText, 
  TrendingUp,
  Heart,
  Activity,
  AlertCircle,
  Clock,
  ArrowRight
} from 'lucide-react';

const Dashboard = () => {
  const { user } = useAuth();

  const doctorStats = [
    {
      title: 'Today\'s Appointments',
      value: '12',
      icon: Calendar,
      color: 'bg-blue-600',
      trend: '+2 from yesterday'
    },
    {
      title: 'Active Patients',
      value: '847',
      icon: Users,
      color: 'bg-green-600',
      trend: '+15 this month'
    },
    {
      title: 'Pending Reviews',
      value: '8',
      icon: FileText,
      color: 'bg-yellow-600',
      trend: '3 urgent'
    },
    {
      title: 'AI Consultations',
      value: '23',
      icon: MessageCircle,
      color: 'bg-purple-600',
      trend: '+5 today'
    }
  ];

  const patientStats = [
    {
      title: 'Next Appointment',
      value: 'Tomorrow',
      icon: Calendar,
      color: 'bg-blue-600',
      trend: 'Dr. Smith - 2:30 PM'
    },
    {
      title: 'Health Score',
      value: '85%',
      icon: Heart,
      color: 'bg-green-600',
      trend: '+5% this week'
    },
    {
      title: 'Active Medications',
      value: '3',
      icon: Activity,
      color: 'bg-orange-600',
      trend: '2 expiring soon'
    },
    {
      title: 'Pending Tests',
      value: '2',
      icon: AlertCircle,
      color: 'bg-red-600',
      trend: 'Blood work due'
    }
  ];

  const stats = user?.role === 'doctor' ? doctorStats : patientStats;

  const upcomingAppointments = [
    {
      id: '1',
      patient: user?.role === 'doctor' ? 'Shreya' : 'Dr. Sarah Smith',
      time: '9:00 AM',
      date: 'Today',
      type: 'Consultation'
    },
    {
      id: '2',
      patient: user?.role === 'doctor' ? 'Jane Smith' : 'Dr. Michael Johnson',
      time: '2:30 PM',
      date: 'Tomorrow',
      type: 'Follow-up'
    },
    {
      id: '3',
      patient: user?.role === 'doctor' ? 'Bob Johnson' : 'Dr. Emily Davis',
      time: '11:00 AM',
      date: 'Friday',
      type: 'Check-up'
    }
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">
          Welcome back, {user?.name}!
        </h1>
        <p className="text-gray-600">
          {user?.role === 'doctor' 
            ? 'Here\'s your practice overview for today'
            : 'Here\'s your health summary'
          }
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-lg ${stat.color}`}>
                <stat.icon className="h-6 w-6 text-white" />
              </div>
              <TrendingUp className="h-5 w-5 text-green-500" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-800 mb-1">{stat.value}</p>
              <p className="text-sm font-medium text-gray-600 mb-2">{stat.title}</p>
              <p className="text-xs text-gray-500">{stat.trend}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Appointments */}
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold text-gray-800">
              Upcoming Appointments
            </h3>
            <Link 
              to="/appointments"
              className="flex items-center space-x-1 text-blue-600 hover:text-blue-700 text-sm font-medium"
            >
              <span>View All</span>
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          
          <div className="space-y-4">
            {upcomingAppointments.map((appointment) => (
              <div key={appointment.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-800">{appointment.patient}</p>
                  <p className="text-sm text-gray-600">{appointment.type}</p>
                </div>
                <div className="text-right">
                  <p className="font-medium text-gray-800">{appointment.time}</p>
                  <p className="text-sm text-gray-600">{appointment.date}</p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-4 pt-4 border-t border-gray-100">
            <Link
              to="/appointments"
              className="flex items-center justify-center space-x-2 w-full py-2 text-blue-600 hover:text-blue-700 font-medium"
            >
              <Calendar className="h-5 w-5" />
              <span>Schedule New Appointment</span>
            </Link>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="text-xl font-semibold text-gray-800 mb-6">
            Recent Activity
          </h3>
          
          <div className="space-y-4">
            {user?.role === 'doctor' ? (
              <>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                  <div>
                    <p className="text-sm font-medium text-gray-800">New patient registered</p>
                    <p className="text-xs text-gray-600">Sarah Johnson - 2 hours ago</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                  <div>
                    <p className="text-sm font-medium text-gray-800">Appointment completed</p>
                    <p className="text-xs text-gray-600">Shreya - 4 hours ago</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2"></div>
                  <div>
                    <p className="text-sm font-medium text-gray-800">Lab results uploaded</p>
                    <p className="text-xs text-gray-600">Multiple patients - 6 hours ago</p>
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                  <div>
                    <p className="text-sm font-medium text-gray-800">Medication reminder</p>
                    <p className="text-xs text-gray-600">Take aspirin - 1 hour ago</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                  <div>
                    <p className="text-sm font-medium text-gray-800">Health metrics updated</p>
                    <p className="text-xs text-gray-600">Blood pressure recorded - 3 hours ago</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-purple-500 rounded-full mt-2"></div>
                  <div>
                    <p className="text-sm font-medium text-gray-800">AI consultation</p>
                    <p className="text-xs text-gray-600">Symptom analysis completed - 5 hours ago</p>
                  </div>
                </div>
              </>
            )}
          </div>
          
          <div className="mt-4 pt-4 border-t border-gray-100">
            <Link
              to="/chat"
              className="flex items-center justify-center space-x-2 w-full py-2 text-purple-600 hover:text-purple-700 font-medium"
            >
              <MessageCircle className="h-5 w-5" />
              <span>Start AI Consultation</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;