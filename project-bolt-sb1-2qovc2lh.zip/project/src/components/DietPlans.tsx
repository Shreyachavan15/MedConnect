import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  Plus, 
  Clock, 
  Users, 
  Heart, 
  Utensils, 
  Calendar,
  Target,
  TrendingUp,
  CheckCircle
} from 'lucide-react';
import { DietPlan, Meal } from '../types';

const DietPlans = () => {
  const { user } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState<DietPlan | null>(null);
  const [showCreatePlan, setShowCreatePlan] = useState(false);

  const dietPlans: DietPlan[] = [
    {
      id: '1',
      patientId: user?.id || '1',
      title: 'Heart-Healthy Diet',
      description: 'Low-sodium, high-fiber diet to support cardiovascular health',
      duration: '30 days',
      createdBy: 'Dr. Sarah Smith',
      createdDate: '2024-01-15',
      meals: [
        {
          id: '1',
          name: 'Oatmeal with Berries',
          time: '7:00 AM',
          foods: ['Steel-cut oats', 'Fresh blueberries', 'Almonds', 'Honey'],
          calories: 350,
          notes: 'Rich in fiber and antioxidants'
        },
        {
          id: '2',
          name: 'Grilled Salmon Salad',
          time: '12:30 PM',
          foods: ['Atlantic salmon', 'Mixed greens', 'Avocado', 'Olive oil vinaigrette'],
          calories: 450,
          notes: 'High in omega-3 fatty acids'
        },
        {
          id: '3',
          name: 'Vegetable Stir-fry',
          time: '6:00 PM',
          foods: ['Broccoli', 'Bell peppers', 'Brown rice', 'Tofu', 'Ginger'],
          calories: 400,
          notes: 'Low sodium, high in vitamins'
        }
      ]
    },
    {
      id: '2',
      patientId: user?.id || '1',
      title: 'Weight Management Plan',
      description: 'Balanced calorie-controlled diet for healthy weight loss',
      duration: '60 days',
      createdBy: 'Dr. Michael Johnson',
      createdDate: '2024-01-10',
      meals: [
        {
          id: '4',
          name: 'Greek Yogurt Parfait',
          time: '7:30 AM',
          foods: ['Greek yogurt', 'Granola', 'Strawberries', 'Chia seeds'],
          calories: 300,
          notes: 'High protein breakfast'
        },
        {
          id: '5',
          name: 'Quinoa Bowl',
          time: '1:00 PM',
          foods: ['Quinoa', 'Chickpeas', 'Cucumber', 'Lemon dressing'],
          calories: 380,
          notes: 'Complete protein source'
        },
        {
          id: '6',
          name: 'Grilled Chicken',
          time: '6:30 PM',
          foods: ['Chicken breast', 'Steamed vegetables', 'Sweet potato'],
          calories: 420,
          notes: 'Lean protein and complex carbs'
        }
      ]
    }
  ];

  const totalCalories = selectedPlan?.meals.reduce((sum, meal) => sum + meal.calories, 0) || 0;

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">Diet Plans</h1>
            <p className="text-gray-600">
              Personalized nutrition plans for your health goals
            </p>
          </div>
          <button
            onClick={() => setShowCreatePlan(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <Plus className="h-5 w-5" />
            <span>Create Plan</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Diet Plans List */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-xl font-semibold text-gray-800">Your Plans</h2>
            </div>
            <div className="divide-y divide-gray-100">
              {dietPlans.map((plan) => (
                <div
                  key={plan.id}
                  onClick={() => setSelectedPlan(plan)}
                  className={`p-6 cursor-pointer transition-colors ${
                    selectedPlan?.id === plan.id ? 'bg-blue-50 border-r-4 border-blue-600' : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="font-semibold text-gray-800">{plan.title}</h3>
                    <div className="flex items-center space-x-1 text-sm text-gray-500">
                      <Clock className="h-4 w-4" />
                      <span>{plan.duration}</span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{plan.description}</p>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center space-x-1 text-gray-500">
                      <Users className="h-4 w-4" />
                      <span>{plan.createdBy}</span>
                    </div>
                    <div className="flex items-center space-x-1 text-green-600">
                      <CheckCircle className="h-4 w-4" />
                      <span>Active</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Plan Details */}
        <div className="lg:col-span-2">
          {selectedPlan ? (
            <div className="space-y-6">
              {/* Plan Header */}
              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-800">{selectedPlan.title}</h2>
                    <p className="text-gray-600">{selectedPlan.description}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold text-blue-600">{totalCalories}</div>
                    <div className="text-sm text-gray-500">Total Calories</div>
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <Target className="h-6 w-6 text-blue-600 mx-auto mb-2" />
                    <div className="text-sm font-medium text-gray-800">Duration</div>
                    <div className="text-lg font-bold text-blue-600">{selectedPlan.duration}</div>
                  </div>
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <Utensils className="h-6 w-6 text-green-600 mx-auto mb-2" />
                    <div className="text-sm font-medium text-gray-800">Meals</div>
                    <div className="text-lg font-bold text-green-600">{selectedPlan.meals.length}</div>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <TrendingUp className="h-6 w-6 text-orange-600 mx-auto mb-2" />
                    <div className="text-sm font-medium text-gray-800">Avg/Meal</div>
                    <div className="text-lg font-bold text-orange-600">{Math.round(totalCalories / selectedPlan.meals.length)}</div>
                  </div>
                </div>
              </div>

              {/* Meals */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-100">
                <div className="p-6 border-b border-gray-100">
                  <h3 className="text-xl font-semibold text-gray-800">Daily Meals</h3>
                </div>
                <div className="divide-y divide-gray-100">
                  {selectedPlan.meals.map((meal) => (
                    <div key={meal.id} className="p-6">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="font-semibold text-gray-800 mb-1">{meal.name}</h4>
                          <div className="flex items-center space-x-1 text-sm text-gray-500">
                            <Clock className="h-4 w-4" />
                            <span>{meal.time}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-bold text-gray-800">{meal.calories}</div>
                          <div className="text-sm text-gray-500">calories</div>
                        </div>
                      </div>
                      
                      <div className="mb-3">
                        <div className="flex flex-wrap gap-2">
                          {meal.foods.map((food, index) => (
                            <span
                              key={index}
                              className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm"
                            >
                              {food}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      {meal.notes && (
                        <div className="flex items-start space-x-2 text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                          <Heart className="h-4 w-4 text-red-500 mt-0.5" />
                          <span>{meal.notes}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-gray-800 mb-1">Plan Progress</h3>
                    <p className="text-sm text-gray-600">Track your adherence and results</p>
                  </div>
                  <div className="flex space-x-3">
                    <button className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                      <CheckCircle className="h-5 w-5" />
                      <span>Log Meal</span>
                    </button>
                    <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                      <Calendar className="h-5 w-5" />
                      <span>View Progress</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center">
              <Utensils className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Select a Diet Plan</h3>
              <p className="text-gray-600">Choose a plan from the list to view details and meals</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DietPlans;