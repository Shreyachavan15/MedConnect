import React, { useState } from 'react';
import { 
  Search, 
  Leaf, 
  Clock, 
  AlertTriangle, 
  Star,
  BookOpen,
  Heart,
  Thermometer,
  Brain,
  Zap
} from 'lucide-react';
import { HomeRemedy } from '../types';

const HomeRemedies = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedRemedy, setSelectedRemedy] = useState<HomeRemedy | null>(null);

  const remedies: HomeRemedy[] = [
    {
      id: '1',
      condition: 'Common Cold',
      title: 'Honey and Ginger Tea',
      description: 'Natural remedy to soothe throat irritation and boost immunity',
      ingredients: ['2 tbsp honey', '1 inch fresh ginger', '1 cup hot water', '1 tsp lemon juice'],
      instructions: [
        'Grate fresh ginger and steep in hot water for 5 minutes',
        'Strain the ginger water',
        'Add honey and lemon juice',
        'Stir well and drink warm',
        'Consume 2-3 times daily'
      ],
      precautions: ['Not suitable for children under 1 year', 'Consult doctor if symptoms persist'],
      effectiveness: 85
    },
    {
      id: '2',
      condition: 'Headache',
      title: 'Peppermint Oil Treatment',
      description: 'Topical application to relieve tension headaches',
      ingredients: ['2-3 drops peppermint oil', '1 tsp carrier oil (coconut/olive)'],
      instructions: [
        'Mix peppermint oil with carrier oil',
        'Apply to temples and forehead',
        'Massage gently in circular motions',
        'Avoid contact with eyes',
        'Rest in a quiet, dark room'
      ],
      precautions: ['Do not apply directly to skin', 'Avoid contact with eyes', 'Test on small skin area first'],
      effectiveness: 75
    },
    {
      id: '3',
      condition: 'Insomnia',
      title: 'Chamomile Tea Ritual',
      description: 'Herbal tea to promote relaxation and better sleep',
      ingredients: ['1 chamomile tea bag', '1 cup hot water', '1 tsp honey (optional)'],
      instructions: [
        'Steep chamomile tea bag in hot water for 5-7 minutes',
        'Remove tea bag and add honey if desired',
        'Drink 30 minutes before bedtime',
        'Create a calm environment',
        'Practice deep breathing while drinking'
      ],
      precautions: ['May cause drowsiness', 'Avoid if allergic to ragweed', 'Consult doctor if taking medications'],
      effectiveness: 70
    },
    {
      id: '4',
      condition: 'Digestive Issues',
      title: 'Fennel Seed Water',
      description: 'Traditional remedy for bloating and indigestion',
      ingredients: ['1 tsp fennel seeds', '1 cup water'],
      instructions: [
        'Boil water and add fennel seeds',
        'Simmer for 10 minutes',
        'Strain and let cool slightly',
        'Drink warm after meals',
        'Can be consumed 2-3 times daily'
      ],
      precautions: ['Pregnant women should consult doctor', 'May interact with blood thinners'],
      effectiveness: 80
    },
    {
      id: '5',
      condition: 'Skin Irritation',
      title: 'Aloe Vera Gel Treatment',
      description: 'Natural soothing gel for minor burns and skin irritation',
      ingredients: ['Fresh aloe vera leaf', 'Clean knife', 'Clean container'],
      instructions: [
        'Cut aloe vera leaf and extract gel',
        'Apply gel directly to affected area',
        'Leave on for 15-20 minutes',
        'Rinse with cool water',
        'Apply 2-3 times daily as needed'
      ],
      precautions: ['Use only fresh aloe vera', 'Test on small area first', 'Avoid if allergic to aloe'],
      effectiveness: 90
    },
    {
      id: '6',
      condition: 'Cough',
      title: 'Turmeric Milk',
      description: 'Anti-inflammatory drink to soothe cough and throat irritation',
      ingredients: ['1 cup warm milk', '1/2 tsp turmeric powder', '1 tsp honey', 'Pinch of black pepper'],
      instructions: [
        'Heat milk until warm (not boiling)',
        'Add turmeric powder and stir well',
        'Add honey and a pinch of black pepper',
        'Mix thoroughly and drink warm',
        'Consume before bedtime'
      ],
      precautions: ['May stain teeth temporarily', 'Avoid if lactose intolerant', 'Consult doctor if cough persists'],
      effectiveness: 78
    }
  ];

  const categories = [
    { id: 'all', name: 'All Remedies', icon: BookOpen },
    { id: 'cold', name: 'Cold & Flu', icon: Thermometer },
    { id: 'pain', name: 'Pain Relief', icon: Heart },
    { id: 'sleep', name: 'Sleep & Stress', icon: Brain },
    { id: 'digestive', name: 'Digestive', icon: Zap },
    { id: 'skin', name: 'Skin Care', icon: Leaf }
  ];

  const filteredRemedies = remedies.filter(remedy => {
    const matchesSearch = remedy.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         remedy.condition.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (selectedCategory === 'all') return matchesSearch;
    
    const categoryMap: { [key: string]: string[] } = {
      'cold': ['Common Cold', 'Cough'],
      'pain': ['Headache'],
      'sleep': ['Insomnia'],
      'digestive': ['Digestive Issues'],
      'skin': ['Skin Irritation']
    };
    
    return matchesSearch && categoryMap[selectedCategory]?.includes(remedy.condition);
  });

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Home Remedies</h1>
        <p className="text-gray-600">
          Natural, time-tested remedies for common health concerns
        </p>
      </div>

      {/* Search and Filter */}
      <div className="mb-6 space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search remedies or conditions..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div className="flex space-x-2 overflow-x-auto pb-2">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
                selectedCategory === category.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <category.icon className="h-5 w-5" />
              <span>{category.name}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Remedies List */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 max-h-[800px] overflow-y-auto">
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-xl font-semibold text-gray-800">
                {filteredRemedies.length} Remedies Found
              </h2>
            </div>
            <div className="divide-y divide-gray-100">
              {filteredRemedies.map((remedy) => (
                <div
                  key={remedy.id}
                  onClick={() => setSelectedRemedy(remedy)}
                  className={`p-6 cursor-pointer transition-colors ${
                    selectedRemedy?.id === remedy.id ? 'bg-blue-50 border-r-4 border-blue-600' : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-semibold text-gray-800 mb-1">{remedy.title}</h3>
                      <p className="text-sm text-blue-600 font-medium">{remedy.condition}</p>
                    </div>
                    <div className="flex items-center space-x-1 text-sm text-yellow-600">
                      <Star className="h-4 w-4 fill-current" />
                      <span>{remedy.effectiveness}%</span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{remedy.description}</p>
                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <div className="flex items-center space-x-1">
                      <Leaf className="h-4 w-4" />
                      <span>{remedy.ingredients.length} ingredients</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="h-4 w-4" />
                      <span>{remedy.instructions.length} steps</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Remedy Details */}
        <div className="lg:col-span-2">
          {selectedRemedy ? (
            <div className="space-y-6">
              {/* Header */}
              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-800 mb-2">{selectedRemedy.title}</h2>
                    <p className="text-blue-600 font-medium mb-2">For {selectedRemedy.condition}</p>
                    <p className="text-gray-600">{selectedRemedy.description}</p>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600">{selectedRemedy.effectiveness}%</div>
                    <div className="text-sm text-gray-500">Effectiveness</div>
                  </div>
                </div>
              </div>

              {/* Ingredients */}
              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                  <Leaf className="h-6 w-6 text-green-600 mr-2" />
                  Ingredients
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {selectedRemedy.ingredients.map((ingredient, index) => (
                    <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-gray-800">{ingredient}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Instructions */}
              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                  <BookOpen className="h-6 w-6 text-blue-600 mr-2" />
                  Instructions
                </h3>
                <div className="space-y-4">
                  {selectedRemedy.instructions.map((step, index) => (
                    <div key={index} className="flex items-start space-x-4">
                      <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-medium">
                        {index + 1}
                      </div>
                      <p className="text-gray-700 pt-1">{step}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Precautions */}
              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                  <AlertTriangle className="h-6 w-6 text-yellow-600 mr-2" />
                  Precautions
                </h3>
                <div className="space-y-3">
                  {selectedRemedy.precautions.map((precaution, index) => (
                    <div key={index} className="flex items-start space-x-3 p-3 bg-yellow-50 rounded-lg">
                      <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-800">{precaution}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Disclaimer */}
              <div className="bg-red-50 border border-red-200 rounded-xl p-6">
                <div className="flex items-start space-x-3">
                  <AlertTriangle className="h-6 w-6 text-red-600 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-red-800 mb-2">Important Disclaimer</h4>
                    <p className="text-sm text-red-700">
                      These home remedies are for informational purposes only and should not replace professional medical advice. 
                      Always consult with a healthcare provider before trying new treatments, especially if you have existing 
                      health conditions or are taking medications.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center">
              <Leaf className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Select a Home Remedy</h3>
              <p className="text-gray-600">Choose a remedy from the list to view detailed instructions and precautions</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default HomeRemedies;