import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  Send, 
  Bot, 
  User, 
  AlertTriangle, 
  Heart, 
  Brain,
  Stethoscope,
  Languages,
  Volume2
} from 'lucide-react';
import { ChatMessage, HealthAnalysis } from '../types';

const AIChat = () => {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      userId: 'ai',
      message: `Hello ${user?.name || 'there'}! I'm your AI health assistant. I can help analyze your symptoms, provide health insights, and answer medical questions. How can I help you today?`,
      timestamp: new Date().toISOString(),
      isAI: true
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const analyzeSymptoms = (message: string): HealthAnalysis => {
    const lowerMessage = message.toLowerCase();
    
    // Simple symptom analysis (in a real app, this would be AI-powered)
    const symptoms: string[] = [];
    const possibleConditions: string[] = [];
    const recommendations: string[] = [];
    let urgency: 'low' | 'medium' | 'high' = 'low';

    // Symptom detection
    if (lowerMessage.includes('headache') || lowerMessage.includes('head pain')) {
      symptoms.push('Headache');
      possibleConditions.push('Tension headache', 'Migraine', 'Dehydration');
      recommendations.push('Rest in a quiet, dark room', 'Stay hydrated', 'Consider over-the-counter pain relief');
    }

    if (lowerMessage.includes('fever') || lowerMessage.includes('temperature')) {
      symptoms.push('Fever');
      possibleConditions.push('Viral infection', 'Bacterial infection');
      recommendations.push('Monitor temperature', 'Stay hydrated', 'Rest');
      urgency = 'medium';
    }

    if (lowerMessage.includes('chest pain') || lowerMessage.includes('heart pain')) {
      symptoms.push('Chest pain');
      possibleConditions.push('Heart attack', 'Angina', 'Muscle strain');
      recommendations.push('Seek immediate medical attention', 'Call emergency services');
      urgency = 'high';
    }

    if (lowerMessage.includes('cough') || lowerMessage.includes('coughing')) {
      symptoms.push('Cough');
      possibleConditions.push('Common cold', 'Flu', 'Bronchitis');
      recommendations.push('Stay hydrated', 'Use honey for throat soothing', 'Rest');
    }

    if (lowerMessage.includes('nausea') || lowerMessage.includes('vomiting')) {
      symptoms.push('Nausea');
      possibleConditions.push('Food poisoning', 'Gastritis', 'Viral infection');
      recommendations.push('Stay hydrated', 'BRAT diet', 'Rest');
    }

    // Default response if no symptoms detected
    if (symptoms.length === 0) {
      return {
        symptoms: [],
        possibleConditions: [],
        recommendations: ['Please describe your symptoms in more detail for better analysis'],
        urgency: 'low',
        suggestedActions: ['Schedule a routine check-up if you have ongoing concerns']
      };
    }

    const suggestedActions = urgency === 'high' 
      ? ['Seek immediate medical attention', 'Go to emergency room']
      : urgency === 'medium'
      ? ['Consider scheduling an appointment with your doctor', 'Monitor symptoms closely']
      : ['Self-care measures may help', 'Schedule appointment if symptoms persist'];

    return {
      symptoms,
      possibleConditions,
      recommendations,
      urgency,
      suggestedActions
    };
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      userId: user?.id || 'user',
      message: inputMessage,
      timestamp: new Date().toISOString(),
      isAI: false
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsLoading(true);

    // Simulate AI processing
    setTimeout(() => {
      const analysis = analyzeSymptoms(inputMessage);
      
      let aiResponse = '';
      if (analysis.symptoms.length > 0) {
        aiResponse = `I've analyzed your symptoms and here's what I found:\n\n`;
        aiResponse += `**Symptoms identified:** ${analysis.symptoms.join(', ')}\n\n`;
        aiResponse += `**Possible conditions:** ${analysis.possibleConditions.join(', ')}\n\n`;
        aiResponse += `**Recommendations:** ${analysis.recommendations.join(', ')}\n\n`;
        aiResponse += `**Urgency level:** ${analysis.urgency.toUpperCase()}\n\n`;
        aiResponse += `**Suggested actions:** ${analysis.suggestedActions.join(', ')}`;
        
        if (analysis.urgency === 'high') {
          aiResponse += '\n\n⚠️ **IMPORTANT:** This appears to be a high-urgency situation. Please seek immediate medical attention.';
        }
      } else {
        aiResponse = analysis.recommendations[0];
      }

      const aiMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        userId: 'ai',
        message: aiResponse,
        timestamp: new Date().toISOString(),
        isAI: true,
        analysis
      };

      setMessages(prev => [...prev, aiMessage]);
      setIsLoading(false);
    }, 1500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const translateMessage = (message: string) => {
    // Simple translation demo (in real app, use Google Translate API)
    const translations: { [key: string]: { [key: string]: string } } = {
      'es': {
        'Hello': 'Hola',
        'How can I help you': 'Como puedo ayudarte',
        'symptoms': 'síntomas',
        'fever': 'fiebre',
        'headache': 'dolor de cabeza'
      },
      'fr': {
        'Hello': 'Bonjour',
        'How can I help you': 'Comment puis-je vous aider',
        'symptoms': 'symptômes',
        'fever': 'fièvre',
        'headache': 'mal de tête'
      }
    };

    if (selectedLanguage === 'en') return message;
    
    let translatedMessage = message;
    const languageDict = translations[selectedLanguage];
    
    if (languageDict) {
      Object.entries(languageDict).forEach(([english, translated]) => {
        translatedMessage = translatedMessage.replace(new RegExp(english, 'gi'), translated);
      });
    }
    
    return translatedMessage;
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Brain className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-gray-800">AI Health Assistant</h1>
              <p className="text-sm text-gray-600">Powered by advanced medical AI</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Languages className="h-5 w-5 text-gray-500" />
              <select 
                value={selectedLanguage}
                onChange={(e) => setSelectedLanguage(e.target.value)}
                className="border border-gray-300 rounded-md px-3 py-1 text-sm"
              >
                <option value="en">English</option>
                <option value="es">Español</option>
                <option value="fr">Français</option>
              </select>
            </div>
            <button className="p-2 text-gray-500 hover:text-gray-700">
              <Volume2 className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.isAI ? 'justify-start' : 'justify-end'}`}
          >
            <div
              className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                message.isAI
                  ? 'bg-white text-gray-800 border border-gray-200'
                  : 'bg-blue-600 text-white'
              }`}
            >
              <div className="flex items-center space-x-2 mb-2">
                {message.isAI ? (
                  <Bot className="h-4 w-4" />
                ) : (
                  <User className="h-4 w-4" />
                )}
                <span className="text-xs font-medium">
                  {message.isAI ? 'AI Assistant' : user?.name}
                </span>
              </div>
              
              <div className="whitespace-pre-line text-sm">
                {translateMessage(message.message)}
              </div>
              
              {message.analysis && (
                <div className="mt-3 p-3 bg-gray-50 rounded-md">
                  <div className="flex items-center space-x-2 mb-2">
                    <Stethoscope className="h-4 w-4 text-blue-600" />
                    <span className="text-xs font-medium text-gray-700">Analysis Summary</span>
                  </div>
                  
                  <div className="space-y-2 text-xs">
                    {message.analysis.urgency === 'high' && (
                      <div className="flex items-center space-x-2 text-red-600">
                        <AlertTriangle className="h-4 w-4" />
                        <span>High Priority</span>
                      </div>
                    )}
                    
                    {message.analysis.urgency === 'medium' && (
                      <div className="flex items-center space-x-2 text-yellow-600">
                        <Heart className="h-4 w-4" />
                        <span>Medium Priority</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
              
              <div className="text-xs text-gray-500 mt-2">
                {new Date(message.timestamp).toLocaleTimeString()}
              </div>
            </div>
          </div>
        ))}
        
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white border border-gray-200 rounded-lg px-4 py-2">
              <div className="flex items-center space-x-2">
                <Bot className="h-4 w-4" />
                <span className="text-sm">AI is analyzing...</span>
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="bg-white border-t border-gray-200 p-4">
        <div className="flex items-center space-x-2">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Describe your symptoms or ask a health question..."
            className="flex-1 border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <button
            onClick={handleSendMessage}
            disabled={!inputMessage.trim() || isLoading}
            className="bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Send className="h-5 w-5" />
          </button>
        </div>
        
        <div className="mt-2 text-xs text-gray-500">
          Press Enter to send • This AI assistant provides general health information and should not replace professional medical advice
        </div>
      </div>
    </div>
  );
};

export default AIChat;