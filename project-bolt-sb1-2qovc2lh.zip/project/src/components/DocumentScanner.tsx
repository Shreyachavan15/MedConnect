import React, { useState, useRef } from 'react';
import { Camera, Upload, FileText, Eye, Download, Languages, Volume2, Calendar, MessageCircle } from 'lucide-react';

const DocumentScanner = () => {
  const [scannedDocument, setScannedDocument] = useState<string | null>(null);
  const [extractedText, setExtractedText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const [translatedText, setTranslatedText] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setScannedDocument(result);
        processDocument(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const processDocument = async (imageData: string) => {
    setIsProcessing(true);
    
    // Simulate OCR processing
    setTimeout(() => {
      // Mock extracted text (in real app, use OCR service like Tesseract.js)
      const mockText = `
MEDICAL PRESCRIPTION

Dr. Sarah Smith, MD
Cardiology Department
City Hospital

Patient: Shreya
Date: ${new Date().toLocaleDateString()}
DOB: 05/15/1990

Diagnosis: Hypertension, Stage 1

Prescription:
1. Lisinopril 10mg - Take once daily in the morning
2. Hydrochlorothiazide 25mg - Take once daily with food
3. Amlodipine 5mg - Take once daily in the evening

Instructions:
- Monitor blood pressure daily
- Reduce sodium intake
- Exercise regularly (30 minutes daily)
- Follow up in 4 weeks

Dr. Sarah Smith
License: MD12345
      `;
      
      setExtractedText(mockText);
      setIsProcessing(false);
    }, 2000);
  };

  const translateDocument = () => {
    // Simple translation (in real app, use Google Translate API)
    const translations: { [key: string]: string } = {
      'es': `
PRESCRIPCIÓN MÉDICA

Dr. Sarah Smith, MD
Departamento de Cardiología
Hospital de la Ciudad

Paciente: Shreya
Fecha: ${new Date().toLocaleDateString()}
Fecha de Nacimiento: 05/15/1990

Diagnóstico: Hipertensión, Etapa 1

Prescripción:
1. Lisinopril 10mg - Tomar una vez al día por la mañana
2. Hidroclorotiazida 25mg - Tomar una vez al día con comida
3. Amlodipina 5mg - Tomar una vez al día por la noche

Instrucciones:
- Monitorear la presión arterial diariamente
- Reducir la ingesta de sodio
- Ejercitarse regularmente (30 minutos diarios)
- Seguimiento en 4 semanas

Dr. Sarah Smith
Licencia: MD12345
      `,
      'fr': `
PRESCRIPTION MÉDICALE

Dr. Sarah Smith, MD
Département de Cardiologie
Hôpital de la Ville

Patient: Shreya
Date: ${new Date().toLocaleDateString()}
Date de naissance: 05/15/1990

Diagnostic: Hypertension, Stade 1

Prescription:
1. Lisinopril 10mg - Prendre une fois par jour le matin
2. Hydrochlorothiazide 25mg - Prendre une fois par jour avec nourriture
3. Amlodipine 5mg - Prendre une fois par jour le soir

Instructions:
- Surveiller la tension artérielle quotidiennement
- Réduire l'apport en sodium
- Exercice régulier (30 minutes par jour)
- Suivi dans 4 semaines

Dr. Sarah Smith
Licence: MD12345
      `
    };

    setTranslatedText(translations[selectedLanguage] || extractedText);
  };

  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = selectedLanguage === 'es' ? 'es-ES' : selectedLanguage === 'fr' ? 'fr-FR' : 'en-US';
      speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Document Scanner</h1>
        <p className="text-gray-600">
          Scan and extract text from medical documents, prescriptions, and lab reports
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Scanner Section */}
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Upload Document</h2>
          
          <div className="space-y-4">
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
              {scannedDocument ? (
                <div className="space-y-4">
                  <img 
                    src={scannedDocument} 
                    alt="Scanned document" 
                    className="max-w-full h-64 object-contain mx-auto rounded-lg"
                  />
                  <div className="flex justify-center space-x-2">
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                    >
                      <Upload className="h-5 w-5" />
                      <span>Upload New</span>
                    </button>
                    <button
                      onClick={() => setScannedDocument(null)}
                      className="flex items-center space-x-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
                    >
                      <Camera className="h-5 w-5" />
                      <span>Clear</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                    <FileText className="h-8 w-8 text-gray-400" />
                  </div>
                  <div>
                    <p className="text-lg font-medium text-gray-600">Upload a document</p>
                    <p className="text-sm text-gray-500">PNG, JPG, or PDF up to 10MB</p>
                  </div>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 mx-auto"
                  >
                    <Upload className="h-5 w-5" />
                    <span>Choose File</span>
                  </button>
                </div>
              )}
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,.pdf"
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>
        </div>

        {/* Results Section */}
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-800">Extracted Text</h2>
            <div className="flex items-center space-x-2">
              <select 
                value={selectedLanguage}
                onChange={(e) => setSelectedLanguage(e.target.value)}
                className="border border-gray-300 rounded-md px-3 py-1 text-sm"
              >
                <option value="en">English</option>
                <option value="es">Español</option>
                <option value="fr">Français</option>
              </select>
              <button
                onClick={translateDocument}
                disabled={!extractedText}
                className="p-2 text-gray-500 hover:text-gray-700 disabled:opacity-50"
              >
                <Languages className="h-5 w-5" />
              </button>
            </div>
          </div>

          {isProcessing ? (
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <p className="text-gray-600">Processing document...</p>
              </div>
            </div>
          ) : extractedText ? (
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-4 max-h-96 overflow-y-auto">
                <pre className="text-sm text-gray-800 whitespace-pre-wrap font-mono">
                  {translatedText || extractedText}
                </pre>
              </div>
              
              <div className="flex space-x-2">
                <button
                  onClick={() => speakText(translatedText || extractedText)}
                  className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  <Volume2 className="h-5 w-5" />
                  <span>Read Aloud</span>
                </button>
                
                <button
                  onClick={() => {
                    const element = document.createElement('a');
                    const file = new Blob([translatedText || extractedText], { type: 'text/plain' });
                    element.href = URL.createObjectURL(file);
                    element.download = 'extracted-text.txt';
                    document.body.appendChild(element);
                    element.click();
                    document.body.removeChild(element);
                  }}
                  className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  <Download className="h-5 w-5" />
                  <span>Download</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <Eye className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">Upload a document to extract text</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="mt-8 bg-white rounded-xl shadow-sm p-6 border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="flex items-center space-x-3 p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
            <FileText className="h-6 w-6 text-blue-600" />
            <div className="text-left">
              <p className="font-medium text-gray-800">Save to Records</p>
              <p className="text-sm text-gray-600">Add to medical history</p>
            </div>
          </button>
          
          <button className="flex items-center space-x-3 p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors">
            <Calendar className="h-6 w-6 text-green-600" />
            <div className="text-left">
              <p className="font-medium text-gray-800">Schedule Follow-up</p>
              <p className="text-sm text-gray-600">Book appointment</p>
            </div>
          </button>
          
          <button className="flex items-center space-x-3 p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors">
            <MessageCircle className="h-6 w-6 text-purple-600" />
            <div className="text-left">
              <p className="font-medium text-gray-800">Ask AI</p>
              <p className="text-sm text-gray-600">Get insights</p>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default DocumentScanner;