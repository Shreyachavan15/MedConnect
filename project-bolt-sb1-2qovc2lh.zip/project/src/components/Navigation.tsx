import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { 
  HeartHandshake, 
  Calendar, 
  MessageCircle, 
  Users, 
  FileText, 
  Settings,
  LogOut,
  Home,
  User,
  Camera,
  Utensils,
  Leaf
} from 'lucide-react';

const Navigation = () => {
  const { user, logout } = useAuth();
  const location = useLocation();

  const doctorLinks = [
    { to: '/dashboard', icon: Home, label: 'Dashboard' },
    { to: '/appointments', icon: Calendar, label: 'Appointments' },
    { to: '/patients', icon: Users, label: 'Patients' },
    { to: '/chat', icon: MessageCircle, label: 'AI Assistant' },
    { to: '/documents', icon: FileText, label: 'Documents' },
  ];

  const patientLinks = [
    { to: '/dashboard', icon: Home, label: 'Dashboard' },
    { to: '/appointments', icon: Calendar, label: 'My Appointments' },
    { to: '/records', icon: FileText, label: 'Medical Records' },
    { to: '/chat', icon: MessageCircle, label: 'AI Health Chat' },
    { to: '/scan', icon: Camera, label: 'Scan Documents' },
    { to: '/diet', icon: Utensils, label: 'Diet Plans' },
    { to: '/remedies', icon: Leaf, label: 'Home Remedies' },
  ];

  const links = user?.role === 'doctor' ? doctorLinks : patientLinks;

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="bg-white shadow-lg border-r border-gray-200 w-64 min-h-screen">
      <div className="p-6">
        <div className="flex items-center space-x-2 mb-8">
          <HeartHandshake className="h-8 w-8 text-blue-600" />
          <span className="text-xl font-bold text-gray-800">MedConnect</span>
        </div>
        
        <div className="flex items-center space-x-3 mb-6 p-3 bg-gray-50 rounded-lg">
          <img 
            src={user?.avatar || 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=400'} 
            alt={user?.name}
            className="w-10 h-10 rounded-full object-cover"
          />
          <div>
            <p className="font-semibold text-gray-800">{user?.name}</p>
            <p className="text-sm text-gray-600 capitalize">{user?.role}</p>
          </div>
        </div>

        <ul className="space-y-2">
          {links.map((link) => (
            <li key={link.to}>
              <Link
                to={link.to}
                className={`flex items-center space-x-3 p-3 rounded-lg transition-colors ${
                  isActive(link.to)
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <link.icon className="h-5 w-5" />
                <span>{link.label}</span>
              </Link>
            </li>
          ))}
        </ul>

        <div className="mt-8 pt-6 border-t border-gray-200">
          <Link
            to="/profile"
            className="flex items-center space-x-3 p-3 rounded-lg text-gray-700 hover:bg-gray-100 transition-colors mb-2"
          >
            <User className="h-5 w-5" />
            <span>Profile</span>
          </Link>
          
          <Link
            to="/settings"
            className="flex items-center space-x-3 p-3 rounded-lg text-gray-700 hover:bg-gray-100 transition-colors mb-2"
          >
            <Settings className="h-5 w-5" />
            <span>Settings</span>
          </Link>
          
          <button
            onClick={logout}
            className="flex items-center space-x-3 p-3 rounded-lg text-red-600 hover:bg-red-50 transition-colors w-full"
          >
            <LogOut className="h-5 w-5" />
            <span>Logout</span>
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;